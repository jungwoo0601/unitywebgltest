import React, { useEffect } from "react";
import { Unity, useUnityContext } from "react-unity-webgl";
import "./UnityGame.css";

const UnityGame = () => {
  const { unityProvider, isLoaded, requestFullscreen, sendMessage } =
    useUnityContext({
      loaderUrl: "Build/Dont_Shoot_Slime.loader.js",
      dataUrl: "Build/Dont_Shoot_Slime.data.br",
      frameworkUrl: "Build/Dont_Shoot_Slime.framework.js.br",
      codeUrl: "Build/Dont_Shoot_Slime.wasm.br",
    });

  // Unity가 로드된 후 전체 화면 모드를 요청
  useEffect(() => {
    if (isLoaded) {
      requestFullscreen(true); // 전체 화면 모드를 요청
    }
  }, [isLoaded, requestFullscreen]);

  return (
    <>
      <div className="unity-game-container">
        <Unity
          unityProvider={unityProvider}
          style={{
            width: "100%",
            height: "100%",
          }}
        />
      </div>
      <div className="buttons-container">
        <button onClick={() => sendMessage("WebGLTest", "UnityStartRecording")}>
          Start Recording
        </button>
        <button onClick={() => sendMessage("WebGLTest", "UnityStopRecording")}>
          Stop Recording
        </button>
        <button onClick={() => sendMessage("WebGLTest", "UnityDownloadFile")}>
          Download File
        </button>
        <button onClick={() => sendMessage("WebGLTest", "UnityNoAudio")}>
          No Audio
        </button>
      </div>
    </>
  );
};

export default UnityGame;
