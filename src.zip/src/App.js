import React from "react";
import UnityGame from "./UnityGame";

function App() {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        width: "100vw",
        height: "100vh",
        margin: "0",
        padding: "0",
        backgroundColor: "#000",
      }}
    >
      <UnityGame />
    </div>
  );
}

export default App;
